# Dip & Niki Wedding Invitation

Static site. Upload everything in this folder to a GitHub repo, then Settings > Pages > Branch: main, Folder: / (root).
